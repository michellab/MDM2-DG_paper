#cd free
#cp -a template run003
#cd run003
#bash runme.sh
#cd ../..
cd bound
cp -aL template run003
cd run003
bash runme.sh
cd ../..
