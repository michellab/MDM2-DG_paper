cd free
cp -a template run002
cd run002
bash runme.sh
cd ../..
cd bound
cp -aL template run002
cd run002
bash runme.sh
cd ../..
