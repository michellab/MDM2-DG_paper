cd free
cp -a template run004
cd run004
bash runme.sh
cd ../..
cd bound
cp -aL template run004
cd run004
bash runme.sh
cd ../..
