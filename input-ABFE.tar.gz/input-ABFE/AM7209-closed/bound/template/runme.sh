cd discharge
cd output
sbatch ../somd-gpu.sh

cd ..
cd ..
cd vanish
cd output
sbatch ../somd-gpu.sh
cd ..
cd ..

