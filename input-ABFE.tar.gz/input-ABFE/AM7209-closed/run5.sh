cd free
cp -a template run005
cd run005
bash runme.sh
cd ../..
cd bound
cp -aL template run005
cd run005
bash runme.sh
cd ../..
