cd free
cp -a template run001
cd run001
bash runme.sh
cd ../..
cd bound
cp -aL template run001
cd run001
bash runme.sh
cd ../..
